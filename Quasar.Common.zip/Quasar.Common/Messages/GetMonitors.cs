﻿using ProtoBuf;

namespace Quasar.Common.Messages
{
    [ProtoContract]
    public class GetMonitors : IMessage
    {
    }
}
