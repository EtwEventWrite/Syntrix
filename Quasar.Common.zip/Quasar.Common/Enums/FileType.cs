﻿namespace Quasar.Common.Enums
{
    public enum FileType
    {
        File,
        Directory,
        Back
    }
}
