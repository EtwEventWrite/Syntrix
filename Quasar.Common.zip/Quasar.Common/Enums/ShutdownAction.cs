﻿namespace Quasar.Common.Enums
{
    public enum ShutdownAction
    {
        Shutdown,
        Restart,
        Standby
    }
}
